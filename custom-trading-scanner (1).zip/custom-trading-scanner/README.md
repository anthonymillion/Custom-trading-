# Custom Trading Scanner

This app fetches and displays COT and macro fundamentals.

## Features
- Weekly auto-refresh COT data
- FRED API fundamentals
- React + Vite
